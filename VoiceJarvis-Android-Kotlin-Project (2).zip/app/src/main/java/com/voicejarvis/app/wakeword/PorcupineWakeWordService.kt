package com.voicejarvis.app.wakeword

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.voicejarvis.app.R
import com.voicejarvis.app.stt.TurkishSpeechManager
import com.voicejarvis.app.tts.TurkishTTSManager

/**
 * Arka planda SADECE "Jarvis" kelimesini dinleyen offline motor.
 * Ekranda hiçbir rahatsız edici overlay açmaz.
 */
class PorcupineWakeWordService : Service() {

    private var porcupineManager: PorcupineManager? = null
    private val CHANNEL_ID = "VoiceJarvisWakeWordChannel"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(101, buildNotification())
        initPorcupine()
    }

    private fun initPorcupine() {
        try {
            // Picovoice Porcupine Builtin Jarvis / Custom Keyword
            porcupineManager = PorcupineManager.Builder()
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.75f)
                .build(applicationContext, PorcupineManagerCallback { keywordIndex ->
                    if (keywordIndex == 0) {
                        onWakeWordDetected()
                    }
                })
            porcupineManager?.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun onWakeWordDetected() {
        // Kısa ses tonu ile bildirim ver
        TurkishTTSManager.playWakeChime()
        
        // Türkçe STT motorunu dinlemeye geçir
        TurkishSpeechManager.startListening(
            onResult = { recognizedText ->
                // Komut yorumlayıcıya ilet
            },
            onError = {
                // Sessizce bekleme moduna dön
            }
        )
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VoiceJarvis")
            .setContentText("Sessizce 'Jarvis' komutunu bekliyor...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VoiceJarvis Wake Service",
                NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        porcupineManager?.stop()
        porcupineManager?.delete()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}