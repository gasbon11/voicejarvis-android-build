# VoiceJarvis - Evrensel Android Sesli Asistan Mimarisi (Kotlin Production)

"Jarvis" wake word'ü ile uyanan, AccessibilityService ile tüm Android ekranlarını okuyan, tıklayan, yazan ve Google Gemini / OpenAI hibrit zekasıyla çalışan sesli asistan Android projesi.

## Android Studio'da Derleme & APK Alma:
1. Android Studio'yu açın: **File > Open** seçeneğiyle bu klasörü açın.
2. Android Studio otomatik olarak Gradle senkronizasyonunu tamamlayacaktır.
3. Üst menüden: **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçeneğine tıklayın.
4. Veya alt sekmedeki Terminal'den:
   - Windows: `gradlew assembleDebug`
   - Mac/Linux: `./gradlew assembleDebug`
5. Derlenen APK dosyanız **app/build/outputs/apk/debug/app-debug.apk** konumunda hazır olacaktır.

## Telefona Yükleme ve İzinler:
1. APK'yı telefonunuza yükleyin.
2. **Ayarlar > Erişilebilirlik > Yüklü Uygulamalar > VoiceJarvis** servisini AÇIK yapın.
3. Uygulama açılışında Mikrofon iznini verin.
